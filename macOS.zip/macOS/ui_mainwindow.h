/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <linemenu.h>
#include <robotbox1.h>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout_2;
    QGraphicsView *canvas;
    QGroupBox *toolBox;
    QVBoxLayout *verticalLayout_10;
    QGroupBox *lineTools;
    QGridLayout *gridLayout_5;
    LineMenu *frame;
    QGroupBox *robotTools;
    QGridLayout *gridLayout_7;
    robotBox1 *robot1;
    QLabel *robot2;
    QGroupBox *simTools;
    QPushButton *pauseButton;
    QPushButton *resetButton;
    QLabel *label_3;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QProgressBar *progressBar;
    QSlider *speed;
    QWidget *statusBar;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *butClear;
    QPushButton *butExit;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(793, 728);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        canvas = new QGraphicsView(centralwidget);
        canvas->setObjectName(QString::fromUtf8("canvas"));

        gridLayout_2->addWidget(canvas, 0, 1, 1, 1);

        toolBox = new QGroupBox(centralwidget);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        verticalLayout_10 = new QVBoxLayout(toolBox);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        lineTools = new QGroupBox(toolBox);
        lineTools->setObjectName(QString::fromUtf8("lineTools"));
        gridLayout_5 = new QGridLayout(lineTools);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        frame = new LineMenu(lineTools);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);

        gridLayout_5->addWidget(frame, 0, 0, 1, 1);


        verticalLayout_10->addWidget(lineTools);

        robotTools = new QGroupBox(toolBox);
        robotTools->setObjectName(QString::fromUtf8("robotTools"));
        gridLayout_7 = new QGridLayout(robotTools);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        robot1 = new robotBox1(robotTools);
        robot1->setObjectName(QString::fromUtf8("robot1"));
        robot1->setEnabled(true);
        robot1->setMouseTracking(true);
        robot1->setFrameShape(QFrame::Box);
        robot1->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(robot1, 0, 0, 1, 1);

        robot2 = new QLabel(robotTools);
        robot2->setObjectName(QString::fromUtf8("robot2"));
        robot2->setMouseTracking(false);
        robot2->setFrameShape(QFrame::Box);

        gridLayout_7->addWidget(robot2, 1, 0, 1, 1);


        verticalLayout_10->addWidget(robotTools);

        simTools = new QGroupBox(toolBox);
        simTools->setObjectName(QString::fromUtf8("simTools"));
        pauseButton = new QPushButton(simTools);
        pauseButton->setObjectName(QString::fromUtf8("pauseButton"));
        pauseButton->setGeometry(QRect(12, 113, 93, 28));
        resetButton = new QPushButton(simTools);
        resetButton->setObjectName(QString::fromUtf8("resetButton"));
        resetButton->setGeometry(QRect(12, 148, 93, 28));
        label_3 = new QLabel(simTools);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(13, 29, 36, 16));
        layoutWidget = new QWidget(simTools);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(13, 52, 114, 55));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        progressBar = new QProgressBar(layoutWidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setMinimum(1);
        progressBar->setMaximum(15);
        progressBar->setValue(1);

        verticalLayout->addWidget(progressBar);

        speed = new QSlider(layoutWidget);
        speed->setObjectName(QString::fromUtf8("speed"));
        QSizePolicy sizePolicy(QSizePolicy::Ignored, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(speed->sizePolicy().hasHeightForWidth());
        speed->setSizePolicy(sizePolicy);
        speed->setMinimum(1);
        speed->setMaximum(15);
        speed->setOrientation(Qt::Horizontal);

        verticalLayout->addWidget(speed);


        verticalLayout_10->addWidget(simTools);


        gridLayout_2->addWidget(toolBox, 0, 0, 1, 1);

        statusBar = new QWidget(centralwidget);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        statusBar->setMinimumSize(QSize(0, 24));

        gridLayout_2->addWidget(statusBar, 1, 1, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        butClear = new QPushButton(centralwidget);
        butClear->setObjectName(QString::fromUtf8("butClear"));

        horizontalLayout_4->addWidget(butClear);

        butExit = new QPushButton(centralwidget);
        butExit->setObjectName(QString::fromUtf8("butExit"));

        horizontalLayout_4->addWidget(butExit);


        gridLayout_2->addLayout(horizontalLayout_4, 1, 0, 1, 1);


        gridLayout_3->addLayout(gridLayout_2, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 793, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(butExit, SIGNAL(clicked()), MainWindow, SLOT(close()));
        QObject::connect(speed, SIGNAL(valueChanged(int)), progressBar, SLOT(setValue(int)));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Line Robots", nullptr));
        toolBox->setTitle(QCoreApplication::translate("MainWindow", "Tools", nullptr));
        lineTools->setTitle(QCoreApplication::translate("MainWindow", "Line", nullptr));
        robotTools->setTitle(QCoreApplication::translate("MainWindow", "Robot", nullptr));
        robot1->setText(QCoreApplication::translate("MainWindow", "Green Robot", nullptr));
        robot2->setText(QString());
        simTools->setTitle(QCoreApplication::translate("MainWindow", "Simulation", nullptr));
        pauseButton->setText(QCoreApplication::translate("MainWindow", "Pause", nullptr));
        resetButton->setText(QCoreApplication::translate("MainWindow", "Reset", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Speed", nullptr));
        progressBar->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        butClear->setText(QCoreApplication::translate("MainWindow", "Clear", nullptr));
        butExit->setText(QCoreApplication::translate("MainWindow", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
